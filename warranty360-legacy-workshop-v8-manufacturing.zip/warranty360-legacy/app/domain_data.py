import json,random,datetime
from .store import connect,setup

def generate_domain(count=6000,seed=4100):
    r=random.Random(seed+9211)
    sites=['IN-BLR','US-TX','DE-BY','JP-KN','GB-ENG','BR-SP']
    with connect() as c:
        c.execute('CREATE TABLE IF NOT EXISTS products(product_id TEXT PRIMARY KEY, product_family TEXT NOT NULL, build_plant TEXT NOT NULL, supplier_lot TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS claims(claim_id TEXT PRIMARY KEY, product_id TEXT NOT NULL REFERENCES products(product_id), service_date TEXT NOT NULL, part_code TEXT NOT NULL, claim_amount REAL NOT NULL, disposition TEXT NOT NULL)')
        c.execute('DELETE FROM claims')
        c.execute('DELETE FROM products')
        n=max(30,count//8)
        parents=[]
        for i in range(n):
            row=('P%07d' % i, r.choice(['pump','controller','motor','valve']),r.choice(sites),f'SUP-{r.randint(1,350):04d}')
            c.execute('INSERT INTO products VALUES ({})'.format(','.join('?'*len(row))),row)
            parents.append(row[0])
        for i in range(count):
            product_id=r.choice(parents)
            day=(datetime.date(2023,1,1)+datetime.timedelta(days=r.randint(0,1090))).isoformat()
            row=(f'W{i:08d}', product_id, day, r.choice(['CP-011','EL-410','MG-221']), round(r.lognormvariate(6.5,.7),2), r.choice(['OPEN','REVIEW','PAID','DENIED']))
            c.execute('INSERT INTO claims VALUES ({})'.format(','.join('?'*len(row))),row)
    return {'entity':'products','entity_count':n,'detail':'claims','detail_count':count}

if __name__=='__main__':
 import argparse
 a=argparse.ArgumentParser(); a.add_argument('--count',type=int,default=6000); a.add_argument('--seed',type=int,default=4100); args=a.parse_args()
 print(json.dumps(generate_domain(args.count,args.seed)))
