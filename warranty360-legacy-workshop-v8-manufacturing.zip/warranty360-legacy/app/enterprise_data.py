import datetime, json, random
from .store import connect
TABLES = [('dealer_network', 'dealer_id TEXT PRIMARY KEY, territory TEXT NOT NULL, tier TEXT NOT NULL, activation_date TEXT NOT NULL'), ('service_visits', 'visit_id TEXT PRIMARY KEY, claim_id TEXT NOT NULL REFERENCES claims(claim_id), dealer_id TEXT NOT NULL REFERENCES dealer_network(dealer_id), mileage_km INTEGER, failure_code TEXT NOT NULL, technician_note TEXT NOT NULL, visit_at TEXT NOT NULL'), ('supplier_quality', 'finding_id TEXT PRIMARY KEY, supplier_lot TEXT NOT NULL, defect_family TEXT NOT NULL, ppk REAL, disposition TEXT NOT NULL, finding_at TEXT NOT NULL'), ('warranty_reserves', 'period TEXT NOT NULL, product_family TEXT NOT NULL, reserve_usd REAL NOT NULL, PRIMARY KEY(period,product_family)')]
DOMAIN = 'Manufacturing'
PHRASES = ['dealer disputes liability despite a repeat field failure', 'unidentified supplier lot in manually keyed claim', 'component inspection mentions bearing noise in cold start']

def expand(seed=4100):
    rng = random.Random(seed + 77019)
    with connect() as c:
        for name,ddl in TABLES:
            c.execute('CREATE TABLE IF NOT EXISTS '+name+'('+ddl+')')
        for name,_ in reversed(TABLES):
            c.execute('DELETE FROM '+name)
        parents = [x[0] for x in c.execute('SELECT product_id FROM products')]
        n=len(parents)
        if not n: raise RuntimeError('Domain data missing: generate base data first')
        date0=datetime.datetime(2023,1,1,tzinfo=datetime.timezone.utc)
        def ts(i):return (date0+datetime.timedelta(hours=i*7)).isoformat()
        claims=[dict(x) for x in c.execute('SELECT claim_id,product_id,service_date FROM claims ORDER BY claim_id')]
        for i in range(max(30,n//3)):
            c.execute('INSERT INTO dealer_network VALUES (?,?,?,?)',(f'D{i:06d}',rng.choice(['APAC','NA','EMEA','LATAM']),rng.choice(['gold','silver','independent']),ts(i)))
        dealers=[x[0] for x in c.execute('SELECT dealer_id FROM dealer_network')]
        for i,row in enumerate(claims):
            c.execute('INSERT INTO service_visits VALUES (?,?,?,?,?,?,?)',(f'V{i:08d}',row['claim_id'],rng.choice(dealers),rng.choice([None,rng.randint(500,290000)]),rng.choice(['BEARING','ELEC','LEAK','VIB','UNKNOWN']),rng.choice(PHRASES),ts(i)))
        for i in range(max(150,n//2)):
            c.execute('INSERT INTO supplier_quality VALUES (?,?,?,?,?,?)',(f'SQ{i:07d}',f'SUP-{rng.randint(1,350):04d}',rng.choice(['fatigue','fracture','contamination','porosity']),round(rng.uniform(.4,2.3),3),rng.choice(['OPEN','SCAR','CLOSED']),ts(i)))
        for i in range(36):
            for fam in ['pump','controller','motor','valve']:
                c.execute('INSERT INTO warranty_reserves VALUES (?,?,?)',(f'{2023+i//12}-{1+i%12:02}',fam,round(rng.uniform(20000,500000),2)))
        return {t:c.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t,_ in TABLES}
