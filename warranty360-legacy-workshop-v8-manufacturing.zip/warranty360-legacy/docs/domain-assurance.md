# Domain operational record
System: Warranty claims and supplier parts. Domain entities include: warranty_claims, service_visits, supplier_quality_findings, warranty_reserves; shared reference records, finance ledger and historical events are in separate file/database estates.

Decision requiring authorized human review: `claim_decision`.
Applicable background concerns: NHTSA EWR categories and ISO 9001-inspired quality record controls. This exercise provides a synthetic training environment, **not** compliance certification.

Business metrics: backlog aging, unsafe action count, reconciliation delay, time to evidence, and unresolved exception rate. Domain safety acceptance requires preserving existing human approval gates, no silent cross-tenant action, and source attribution for each decision.
