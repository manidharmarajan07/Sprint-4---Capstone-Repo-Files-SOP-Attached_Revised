# Domain records and local endpoints

- `GET /api/domain/dealer_network?limit=20&offset=0` — relational record with schema `dealer_id TEXT PRIMARY KEY, territory TEXT NOT NULL, tier TEXT NOT NULL, activation_date TEXT NOT NULL`
- `GET /api/domain/service_visits?limit=20&offset=0` — relational record with schema `visit_id TEXT PRIMARY KEY, claim_id TEXT NOT NULL REFERENCES claims(claim_id), dealer_id TEXT NOT NULL REFERENCES dealer_network(dealer_id), mileage_km INTEGER, failure_code TEXT NOT NULL, technician_note TEXT NOT NULL, visit_at TEXT NOT NULL`
- `GET /api/domain/supplier_quality?limit=20&offset=0` — relational record with schema `finding_id TEXT PRIMARY KEY, supplier_lot TEXT NOT NULL, defect_family TEXT NOT NULL, ppk REAL, disposition TEXT NOT NULL, finding_at TEXT NOT NULL`
- `GET /api/domain/warranty_reserves?limit=20&offset=0` — relational record with schema `period TEXT NOT NULL, product_family TEXT NOT NULL, reserve_usd REAL NOT NULL, PRIMARY KEY(period,product_family)`

All records are synthetic. Resource endpoints expose legacy read models and should not be assumed to be complete domain APIs.
