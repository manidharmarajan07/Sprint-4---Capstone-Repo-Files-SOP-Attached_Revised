# Domain data dictionary

The legacy application includes shared intake tables (`cases`, `events`, `source_messages`, `operating_costs`) and these additional domain tables:

- `products`: product_id TEXT PRIMARY KEY, product_family TEXT NOT NULL, build_plant TEXT NOT NULL, supplier_lot TEXT NOT NULL
- `claims`: claim_id TEXT PRIMARY KEY, product_id TEXT NOT NULL REFERENCES products(product_id), service_date TEXT NOT NULL, part_code TEXT NOT NULL, claim_amount REAL NOT NULL, disposition TEXT NOT NULL

Rows use synthetic identifiers, local site aliases, valid foreign-key relationships and generated historical values. The site, currency, revision and unit choices reflect multiple inherited operational practices rather than a canonical enterprise data model.

Inspect the joins and semantics before deriving KPIs.
