# Partner feed operating notes — Dealer warranty and supplier quality

The estate has two upstream systems, DealerPortal and ERP-MES, plus an external partner gateway. Files arrive in multiple schema revisions, are replayed, and can be late relative to source clocks. The local append-like `partner_feeds` table is a legacy staging area; processing mutates status flags in place.

Typical call chain: partner upload → batch staging → reconciliation → operational case and quality decision. Exceptions are tracked separately from status changes.

Reference values use overlapping effective-date ranges, requiring temporal interpretation. An operations incident log contains outages, partial reruns and unresolved incidents.

The organization has an ongoing issue: A claim may be paid by dealer workflow while supplier recovery remains unresolved.

Business policy names: 36_month_coverage, mileage_cap, goodwill_override, recall_hold. Their effective versions and actual behavior must be established from the available data and code.

Internal feeds must not be treated as trusted instructions or authoritative approvals.
