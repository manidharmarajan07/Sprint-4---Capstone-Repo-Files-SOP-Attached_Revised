# Systems, contracts and operating constraints

**DealerPortal** publishes SERVICE_CLAIM, PART_RETURN, DEALER_ESCALATION messages. **ERP-MES** supplies competing facts and effective-dated master data. Partner files can be replayed and have schema revisions 1.0, 1.1, 2.0, and unsupported variants.

The business manages PUMP, ECU, MOTOR, VALVE; human queues track SUBMITTED, INSPECTED, APPROVED, DENIED, REOPENED. Source timestamps, ingestion timestamps and revision dates are distinct.

Process maps and terminology are not fully agreed across teams. No assumption is made that AI is appropriate for any particular processing step.

Synthetic evidence includes policy exceptions and upstream outages; some records disagree. Historic incidents and operational practice must be cross-checked before proposing changes.
