import json,random,datetime
from .store import connect,setup

def generate_domain(count=6000,seed=4100):
    r=random.Random(seed+9211)
    sites=['IN-BLR','US-TX','DE-BY','JP-KN','GB-ENG','BR-SP']
    with connect() as c:
        c.execute('CREATE TABLE IF NOT EXISTS borrowers(borrower_id TEXT PRIMARY KEY, legal_name TEXT NOT NULL, industry TEXT NOT NULL, domicile TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS facilities(facility_id TEXT PRIMARY KEY, borrower_id TEXT NOT NULL REFERENCES borrowers(borrower_id), outstanding REAL NOT NULL, currency TEXT NOT NULL, debt_service_coverage REAL, covenant_threshold REAL NOT NULL)')
        c.execute('DELETE FROM facilities')
        c.execute('DELETE FROM borrowers')
        n=max(30,count//8)
        parents=[]
        for i in range(n):
            row=(f'B{i:07d}',f'Synthetic Holdings {i}',r.choice(['industrial','retail','services','logistics']),r.choice(sites))
            c.execute('INSERT INTO borrowers VALUES ({})'.format(','.join('?'*len(row))),row)
            parents.append(row[0])
        for i in range(count):
            borrower_id=r.choice(parents)
            day=(datetime.date(2023,1,1)+datetime.timedelta(days=r.randint(0,1090))).isoformat()
            row=(f'F{i:08d}',borrower_id,round(r.lognormvariate(13,1.1),2),r.choice(['USD','EUR','INR','GBP']),round(r.uniform(.5,3.2),3),1.2)
            c.execute('INSERT INTO facilities VALUES ({})'.format(','.join('?'*len(row))),row)
    return {'entity':'borrowers','entity_count':n,'detail':'facilities','detail_count':count}

if __name__=='__main__':
 import argparse
 a=argparse.ArgumentParser(); a.add_argument('--count',type=int,default=6000); a.add_argument('--seed',type=int,default=4100); args=a.parse_args()
 print(json.dumps(generate_domain(args.count,args.seed)))
