import datetime, json, random
from .store import connect
TABLES = [('financial_periods', 'period_id TEXT PRIMARY KEY, borrower_id TEXT NOT NULL REFERENCES borrowers(borrower_id), period_end TEXT NOT NULL, revenue REAL NOT NULL, ebitda REAL, debt REAL NOT NULL, currency TEXT NOT NULL, source_version TEXT NOT NULL'), ('covenant_tests', 'test_id TEXT PRIMARY KEY, facility_id TEXT NOT NULL REFERENCES facilities(facility_id), tested_at TEXT NOT NULL, covenant_code TEXT NOT NULL, observed REAL, threshold REAL NOT NULL, analyst_status TEXT NOT NULL'), ('collateral', 'collateral_id TEXT PRIMARY KEY, facility_id TEXT NOT NULL REFERENCES facilities(facility_id), asset_class TEXT NOT NULL, valuation REAL NOT NULL, valuation_date TEXT NOT NULL, currency TEXT NOT NULL'), ('credit_committee', 'decision_id TEXT PRIMARY KEY, facility_id TEXT NOT NULL REFERENCES facilities(facility_id), committee_at TEXT NOT NULL, recommendation TEXT NOT NULL, approval_state TEXT NOT NULL')]
DOMAIN = 'Banking'
PHRASES = ['audited financials use revised EBITDA definition', 'covenant calculation uses stale exchange rate', 'security valuation expired but facility remained active']

def expand(seed=4100):
    rng = random.Random(seed + 77019)
    with connect() as c:
        for name,ddl in TABLES:
            c.execute('CREATE TABLE IF NOT EXISTS '+name+'('+ddl+')')
        for name,_ in reversed(TABLES):
            c.execute('DELETE FROM '+name)
        parents = [x[0] for x in c.execute('SELECT borrower_id FROM borrowers')]
        n=len(parents)
        if not n: raise RuntimeError('Domain data missing: generate base data first')
        date0=datetime.datetime(2023,1,1,tzinfo=datetime.timezone.utc)
        def ts(i):return (date0+datetime.timedelta(hours=i*7)).isoformat()
        facilities=[dict(x) for x in c.execute('SELECT facility_id,borrower_id,currency FROM facilities ORDER BY facility_id')]
        borrowers=[x[0] for x in c.execute('SELECT borrower_id FROM borrowers')]
        for i,b in enumerate(borrowers):
            for year in [2023,2024,2025]:
                c.execute('INSERT INTO financial_periods VALUES (?,?,?,?,?,?,?,?)',(f'FP{i:06d}{year}',b,f'{year}-12-31',round(rng.uniform(1e6,5e8),2),round(rng.uniform(-1e6,5e7),2) if rng.random()>.09 else None,round(rng.uniform(1e6,2e8),2),rng.choice(['USD','EUR','INR','GBP']),rng.choice(['unaudited-v1','audited-v2','restated-v3'])))
        for i,f in enumerate(facilities):
            observed=round(rng.uniform(.6,2.8),3) if rng.random()>.04 else None
            c.execute('INSERT INTO covenant_tests VALUES (?,?,?,?,?,?,?)',(f'CT{i:08d}',f['facility_id'],ts(i),'DSCR',observed,1.2,rng.choice(['PASS','WATCH','WAIVER','BREACH'])))
            if i%2==0:c.execute('INSERT INTO collateral VALUES (?,?,?,?,?,?)',(f'COL{i:08d}',f['facility_id'],rng.choice(['commercial_property','equipment','receivables']),round(rng.uniform(50000,1e7),2),ts(i)[:10],f['currency']))
            if i%4==0:c.execute('INSERT INTO credit_committee VALUES (?,?,?,?,?)',(f'CC{i:08d}',f['facility_id'],ts(i),rng.choice(['RENEW','REVIEW','REDUCE']),rng.choice(['APPROVED','PENDING','DECLINED'])))
        return {t:c.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t,_ in TABLES}
