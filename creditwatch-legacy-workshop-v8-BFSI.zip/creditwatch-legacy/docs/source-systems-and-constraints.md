# Systems, contracts and operating constraints

**LoanOrigination** publishes FINANCIAL_STATEMENT, COVENANT_NOTICE, COLLATERAL_UPDATE messages. **CoreBanking** supplies competing facts and effective-dated master data. Partner files can be replayed and have schema revisions 1.0, 1.1, 2.0, and unsupported variants.

The business manages TERM_LOAN, REVOLVER, LETTER_OF_CREDIT, SYNDICATED; human queues track DRAFT, UNDER_REVIEW, APPROVED, WATCHLIST, EXPIRED. Source timestamps, ingestion timestamps and revision dates are distinct.

Process maps and terminology are not fully agreed across teams. No assumption is made that AI is appropriate for any particular processing step.

Synthetic evidence includes policy exceptions and upstream outages; some records disagree. Historic incidents and operational practice must be cross-checked before proposing changes.
