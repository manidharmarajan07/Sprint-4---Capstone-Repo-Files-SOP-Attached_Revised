# Domain records and local endpoints

- `GET /api/domain/financial_periods?limit=20&offset=0` — relational record with schema `period_id TEXT PRIMARY KEY, borrower_id TEXT NOT NULL REFERENCES borrowers(borrower_id), period_end TEXT NOT NULL, revenue REAL NOT NULL, ebitda REAL, debt REAL NOT NULL, currency TEXT NOT NULL, source_version TEXT NOT NULL`
- `GET /api/domain/covenant_tests?limit=20&offset=0` — relational record with schema `test_id TEXT PRIMARY KEY, facility_id TEXT NOT NULL REFERENCES facilities(facility_id), tested_at TEXT NOT NULL, covenant_code TEXT NOT NULL, observed REAL, threshold REAL NOT NULL, analyst_status TEXT NOT NULL`
- `GET /api/domain/collateral?limit=20&offset=0` — relational record with schema `collateral_id TEXT PRIMARY KEY, facility_id TEXT NOT NULL REFERENCES facilities(facility_id), asset_class TEXT NOT NULL, valuation REAL NOT NULL, valuation_date TEXT NOT NULL, currency TEXT NOT NULL`
- `GET /api/domain/credit_committee?limit=20&offset=0` — relational record with schema `decision_id TEXT PRIMARY KEY, facility_id TEXT NOT NULL REFERENCES facilities(facility_id), committee_at TEXT NOT NULL, recommendation TEXT NOT NULL, approval_state TEXT NOT NULL`

All records are synthetic. Resource endpoints expose legacy read models and should not be assumed to be complete domain APIs.
