# Internal correspondence — FY2024 (synthetic)
Operations says close Corporate lending and covenant surveillance cases within 48 hours; the compliance team refuses automatic closures without verifiable evidence. Finance has not agreed what counts as a successfully resolved case. This was never formalized in the shared policy repository.
