# Domain operational record
System: Corporate lending and covenant surveillance. Domain entities include: financial_periods, covenant_tests, collateral_records, credit_committee_decisions; shared reference records, finance ledger and historical events are in separate file/database estates.

Decision requiring authorized human review: `credit_approval`.
Applicable background concerns: Basel credit risk concepts, local lending policies and model risk. This exercise provides a synthetic training environment, **not** compliance certification.

Business metrics: backlog aging, unsafe action count, reconciliation delay, time to evidence, and unresolved exception rate. Domain safety acceptance requires preserving existing human approval gates, no silent cross-tenant action, and source attribution for each decision.
