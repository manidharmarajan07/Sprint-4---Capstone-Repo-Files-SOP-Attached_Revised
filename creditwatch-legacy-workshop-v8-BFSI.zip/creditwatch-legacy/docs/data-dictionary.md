# Domain data dictionary

The legacy application includes shared intake tables (`cases`, `events`, `source_messages`, `operating_costs`) and these additional domain tables:

- `borrowers`: borrower_id TEXT PRIMARY KEY, legal_name TEXT NOT NULL, industry TEXT NOT NULL, domicile TEXT NOT NULL
- `facilities`: facility_id TEXT PRIMARY KEY, borrower_id TEXT NOT NULL REFERENCES borrowers(borrower_id), outstanding REAL NOT NULL, currency TEXT NOT NULL, debt_service_coverage REAL, covenant_threshold REAL NOT NULL

Rows use synthetic identifiers, local site aliases, valid foreign-key relationships and generated historical values. The site, currency, revision and unit choices reflect multiple inherited operational practices rather than a canonical enterprise data model.

Inspect the joins and semantics before deriving KPIs.
