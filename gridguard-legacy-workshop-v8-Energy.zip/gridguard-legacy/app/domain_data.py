import json,random,datetime
from .store import connect,setup

def generate_domain(count=6000,seed=4100):
    r=random.Random(seed+9211)
    sites=['IN-BLR','US-TX','DE-BY','JP-KN','GB-ENG','BR-SP']
    with connect() as c:
        c.execute('CREATE TABLE IF NOT EXISTS grid_assets(asset_id TEXT PRIMARY KEY, equipment_type TEXT NOT NULL, substation TEXT NOT NULL, commissioning_year INTEGER NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS inspections(inspection_id TEXT PRIMARY KEY, asset_id TEXT NOT NULL REFERENCES grid_assets(asset_id), temperature_c REAL, oil_ppm REAL, inspected_at TEXT NOT NULL, work_order TEXT)')
        c.execute('DELETE FROM inspections')
        c.execute('DELETE FROM grid_assets')
        n=max(30,count//8)
        parents=[]
        for i in range(n):
            row=(f'A{i:07d}',r.choice(['transformer','breaker','relay','switchgear']),r.choice(sites),r.randint(1987,2025))
            c.execute('INSERT INTO grid_assets VALUES ({})'.format(','.join('?'*len(row))),row)
            parents.append(row[0])
        for i in range(count):
            asset_id=r.choice(parents)
            day=(datetime.date(2023,1,1)+datetime.timedelta(days=r.randint(0,1090))).isoformat()
            row=(f'I{i:08d}',asset_id,round(r.gauss(68,14),2),round(max(0,r.gauss(32,21)),2),day,f'WO-{i:07d}' if r.random()<.35 else None)
            c.execute('INSERT INTO inspections VALUES ({})'.format(','.join('?'*len(row))),row)
    return {'entity':'grid_assets','entity_count':n,'detail':'inspections','detail_count':count}

if __name__=='__main__':
 import argparse
 a=argparse.ArgumentParser(); a.add_argument('--count',type=int,default=6000); a.add_argument('--seed',type=int,default=4100); args=a.parse_args()
 print(json.dumps(generate_domain(args.count,args.seed)))
