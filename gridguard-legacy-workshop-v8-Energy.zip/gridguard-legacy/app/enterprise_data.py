import datetime, json, random
from .store import connect
TABLES = [('telemetry_events', 'telemetry_id TEXT PRIMARY KEY, asset_id TEXT NOT NULL REFERENCES grid_assets(asset_id), measured_at TEXT NOT NULL, received_at TEXT NOT NULL, metric TEXT NOT NULL, value REAL NOT NULL, unit TEXT NOT NULL, quality TEXT NOT NULL'), ('work_orders', 'order_id TEXT PRIMARY KEY, asset_id TEXT NOT NULL REFERENCES grid_assets(asset_id), priority TEXT NOT NULL, status TEXT NOT NULL, opened_at TEXT NOT NULL, completed_at TEXT'), ('asset_connections', 'from_asset TEXT NOT NULL REFERENCES grid_assets(asset_id), to_asset TEXT NOT NULL REFERENCES grid_assets(asset_id), topology_rev TEXT NOT NULL, PRIMARY KEY(from_asset,to_asset)'), ('outage_tickets', 'ticket_id TEXT PRIMARY KEY, asset_id TEXT NOT NULL REFERENCES grid_assets(asset_id), started_at TEXT NOT NULL, restored_at TEXT, affected_customers INTEGER NOT NULL')]
DOMAIN = 'Utilities'
PHRASES = ['SCADA signal received out of order during storm', 'operator reports intermittent relay trip', 'field technician requests isolation confirmation']

def expand(seed=4100):
    rng = random.Random(seed + 77019)
    with connect() as c:
        for name,ddl in TABLES:
            c.execute('CREATE TABLE IF NOT EXISTS '+name+'('+ddl+')')
        for name,_ in reversed(TABLES):
            c.execute('DELETE FROM '+name)
        parents = [x[0] for x in c.execute('SELECT asset_id FROM grid_assets')]
        n=len(parents)
        if not n: raise RuntimeError('Domain data missing: generate base data first')
        date0=datetime.datetime(2023,1,1,tzinfo=datetime.timezone.utc)
        def ts(i):return (date0+datetime.timedelta(hours=i*7)).isoformat()
        assets=[x[0] for x in c.execute('SELECT asset_id FROM grid_assets ORDER BY asset_id')]
        inspections=[dict(x) for x in c.execute('SELECT inspection_id,asset_id FROM inspections ORDER BY inspection_id')]
        for i,r in enumerate(inspections):
            measured=ts(i);received=ts(i+1) if i%19==0 else measured
            c.execute('INSERT INTO telemetry_events VALUES (?,?,?,?,?,?,?,?)',(f'TE{i:09d}',r['asset_id'],measured,received,rng.choice(['oil_temp','vibration','gas_ppm']),round(rng.gauss(66,17),2),rng.choice(['C','mm/s','ppm']),rng.choice(['GOOD','SUSPECT','STALE'])))
            if i%3==0:c.execute('INSERT INTO work_orders VALUES (?,?,?,?,?,?)',(f'WO{i:08d}',r['asset_id'],rng.choice(['P1','P2','P3']),rng.choice(['OPEN','DISPATCHED','DONE']),ts(i),ts(i+48) if i%4==0 else None))
            if i%8==0:c.execute('INSERT INTO outage_tickets VALUES (?,?,?,?,?)',(f'OT{i:08d}',r['asset_id'],ts(i),ts(i+3) if i%2==0 else None,rng.randint(1,12000)))
        for i in range(len(assets)-1):c.execute('INSERT INTO asset_connections VALUES (?,?,?)',(assets[i],assets[i+1],rng.choice(['TOPO-v1','TOPO-v2'])))
        return {t:c.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t,_ in TABLES}
