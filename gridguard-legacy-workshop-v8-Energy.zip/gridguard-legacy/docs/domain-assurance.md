# Domain operational record
System: Utility reliability and maintenance. Domain entities include: asset_telemetry, maintenance_work_orders, asset_connections, outage_tickets; shared reference records, finance ledger and historical events are in separate file/database estates.

Decision requiring authorized human review: `switching_authority`.
Applicable background concerns: NERC CIP-inspired cyber hygiene and operator safe switching boundaries. This exercise provides a synthetic training environment, **not** compliance certification.

Business metrics: backlog aging, unsafe action count, reconciliation delay, time to evidence, and unresolved exception rate. Domain safety acceptance requires preserving existing human approval gates, no silent cross-tenant action, and source attribution for each decision.
