# Domain data dictionary

The legacy application includes shared intake tables (`cases`, `events`, `source_messages`, `operating_costs`) and these additional domain tables:

- `grid_assets`: asset_id TEXT PRIMARY KEY, equipment_type TEXT NOT NULL, substation TEXT NOT NULL, commissioning_year INTEGER NOT NULL
- `inspections`: inspection_id TEXT PRIMARY KEY, asset_id TEXT NOT NULL REFERENCES grid_assets(asset_id), temperature_c REAL, oil_ppm REAL, inspected_at TEXT NOT NULL, work_order TEXT

Rows use synthetic identifiers, local site aliases, valid foreign-key relationships and generated historical values. The site, currency, revision and unit choices reflect multiple inherited operational practices rather than a canonical enterprise data model.

Inspect the joins and semantics before deriving KPIs.
