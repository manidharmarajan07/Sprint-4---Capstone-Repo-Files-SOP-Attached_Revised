# Systems, contracts and operating constraints

**SCADAAdapter** publishes TELEMETRY, PROTECTION_TRIP, WORK_ORDER messages. **EAM-OutageMgmt** supplies competing facts and effective-dated master data. Partner files can be replayed and have schema revisions 1.0, 1.1, 2.0, and unsupported variants.

The business manages FEEDER, RELAY, TRANSFORMER, BREAKER; human queues track ALARM, ACKNOWLEDGED, ISOLATED, WORK_PENDING, CLOSED. Source timestamps, ingestion timestamps and revision dates are distinct.

Process maps and terminology are not fully agreed across teams. No assumption is made that AI is appropriate for any particular processing step.

Synthetic evidence includes policy exceptions and upstream outages; some records disagree. Historic incidents and operational practice must be cross-checked before proposing changes.
