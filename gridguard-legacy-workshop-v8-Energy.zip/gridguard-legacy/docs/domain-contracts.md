# Domain records and local endpoints

- `GET /api/domain/telemetry_events?limit=20&offset=0` — relational record with schema `telemetry_id TEXT PRIMARY KEY, asset_id TEXT NOT NULL REFERENCES grid_assets(asset_id), measured_at TEXT NOT NULL, received_at TEXT NOT NULL, metric TEXT NOT NULL, value REAL NOT NULL, unit TEXT NOT NULL, quality TEXT NOT NULL`
- `GET /api/domain/work_orders?limit=20&offset=0` — relational record with schema `order_id TEXT PRIMARY KEY, asset_id TEXT NOT NULL REFERENCES grid_assets(asset_id), priority TEXT NOT NULL, status TEXT NOT NULL, opened_at TEXT NOT NULL, completed_at TEXT`
- `GET /api/domain/asset_connections?limit=20&offset=0` — relational record with schema `from_asset TEXT NOT NULL REFERENCES grid_assets(asset_id), to_asset TEXT NOT NULL REFERENCES grid_assets(asset_id), topology_rev TEXT NOT NULL, PRIMARY KEY(from_asset,to_asset)`
- `GET /api/domain/outage_tickets?limit=20&offset=0` — relational record with schema `ticket_id TEXT PRIMARY KEY, asset_id TEXT NOT NULL REFERENCES grid_assets(asset_id), started_at TEXT NOT NULL, restored_at TEXT, affected_customers INTEGER NOT NULL`

All records are synthetic. Resource endpoints expose legacy read models and should not be assumed to be complete domain APIs.
